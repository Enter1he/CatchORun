startscene = 1

SceneEnum = {
    "Info";
    "res";
    name = "SceneEnum"
}

defaultScene = "res.default";

fullscreen = true

luatitle = "Catch O\'Run"
_en ={
    dt = 0.015;
    screen = {size = "640x320", name = "screen"};
    1;
    name = "_en";
}

_en.screen.w, _en.screen.h = WxHtoints(_en.screen.size)