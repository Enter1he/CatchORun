local w, h = 32, 32
local CatcherFlame = {
    name = "Flame";
	w = w;
	h = h;

	fmt = ".png";
	numf = 1;
	anim = {
		[1] = { 0, 0, w, h, 3};
        
		name = "Flame";
	};
}
return CatcherFlame